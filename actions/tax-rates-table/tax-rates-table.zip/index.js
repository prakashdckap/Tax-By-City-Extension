/**
 * Tax Rates Table API
 * GET /tax-rates-table
 */

const https = require('https');

// ===== CONFIG =====
const REGION = 'amer';
const NAMESPACE = '3676633-taxbycity-stage';
const COLLECTION = 'tax_rates';

const RAW_GET_DB_TOKEN_URL = `https://adobeioruntime.net/api/v1/namespaces/${NAMESPACE}/actions/get-db-token?result=true&blocking=true`;

const BASIC_AUTH = Buffer.from(
  'b43be220-d54d-4315-96f4-9d0be1b4ad3c:ekK2UmlM0WgFf6bgj5rUwp26va7O5s7sTJLPJS8O2y0uf2X8f628kw0V42jqGJq8'
).toString('base64');

// ===== HELPERS =====
function httpsPost(url, headers = {}, body = null) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const data = body ? JSON.stringify(body) : '';

    const req = https.request(
      {
        hostname: u.hostname,
        path: u.pathname + u.search,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data),
          ...headers
        }
      },
      (res) => {
        let response = '';
        res.on('data', (chunk) => (response += chunk));
        res.on('end', () => {
          try {
            const json = JSON.parse(response);
            if (res.statusCode >= 400) {
              return reject(new Error(json.message || response));
            }
            resolve(json);
          } catch (e) {
            reject(e);
          }
        });
      }
    );

    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// ===== GET TOKEN =====
async function getAccessToken(params = {}) {
  const body = {
    ADOBE_CLIENT_ID: params.ADOBE_CLIENT_ID || process.env.ADOBE_CLIENT_ID,
    ADOBE_CLIENT_SECRET: params.ADOBE_CLIENT_SECRET || process.env.ADOBE_CLIENT_SECRET
  };
  const res = await httpsPost(
    RAW_GET_DB_TOKEN_URL,
    { Authorization: `Basic ${BASIC_AUTH}` },
    body
  );

  const result = res?.response?.result || res?.result || res;
  if (result?.statusCode >= 400) {
    throw new Error(result?.body?.message || result?.body?.error || 'Token request failed');
  }
  return result?.body?.access_token || result?.access_token;
}

// ===== DB FETCH =====
async function fetchTaxRates(token, limit, skip) {
  const url = `https://storage-database-${REGION}.app-builder.int.adp.adobe.io/v1/collection/${COLLECTION}/find`;

  const res = await httpsPost(
    url,
    {
      Authorization: `Bearer ${token}`,
      'x-runtime-namespace': NAMESPACE
    },
    {
      filter: {},
      options: { limit, skip }
    }
  );

  return res?.data || [];
}

// ===== MAIN =====
async function main(params) {
  try {
    const limit = Math.min(parseInt(params.limit) || 100, 1000);
    const skip = parseInt(params.skip) || 0;

    // Step 1: Get Token (pass params so get-db-token gets client id/secret)
    const token = await getAccessToken(params);
    if (!token) throw new Error('Failed to get access token');

    // Step 2: Fetch Data
    const items = await fetchTaxRates(token, limit, skip);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: {
        status: 'Success',
        count: items.length,
        data: items
      }
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: {
        status: 'Error',
        message: error.message
      }
    };
  }
}

exports.main = main;