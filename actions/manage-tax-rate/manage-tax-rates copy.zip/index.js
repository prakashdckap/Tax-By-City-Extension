/**
 * Magento Tax Rate Action - Create/Update Tax Rates in App Builder Database
 * Handles CREATE and UPDATE operations for tax rates using App Builder Database Storage
 * Optionally syncs to Magento if configured
 * 
 * POST /magento-tax-rate - Create tax rate
 * PUT /magento-tax-rate - Update tax rate
 */

const libDb = require('@adobe/aio-lib-db');
const { ObjectId } = require('bson');
const axios = require('axios');

const COLLECTION_NAME = 'tax_rates';
const DEFAULT_REGION = 'amer';

/**
 * Initialize database connection
 */
async function initDb(region = DEFAULT_REGION) {
  try {
    const db = await libDb.init({ region });
    const client = await db.connect();
    const collection = await client.collection(COLLECTION_NAME);
    return { client, collection };
  } catch (error) {
    // Check if it's a database-related error by checking error name or message
    if (error && (error.name === 'DbError' || (error.message && error.message.includes('Database')))) {
      throw new Error(`Database error: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Insert a single tax rate
 */
async function insertTaxRate(taxRate, region = DEFAULT_REGION) {
  let client;
  try {
    const { client: dbClient, collection } = await initDb(region);
    client = dbClient;
    
    // Add timestamps
    const document = {
      ...taxRate,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    const result = await collection.insertOne(document);
    return {
      success: true,
      insertedId: result.insertedId,
      document: { ...document, _id: result.insertedId }
    };
  } catch (error) {
    // Check if it's a database-related error by checking error name or message
    if (error && (error.name === 'DbError' || (error.message && error.message.includes('Database')))) {
      throw new Error(`Database error: ${error.message}`);
    }
    throw error;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

/**
 * Find a single tax rate
 */
async function findOneTaxRate(filter, region = DEFAULT_REGION) {
  let client;
  try {
    const { client: dbClient, collection } = await initDb(region);
    client = dbClient;
    
    const result = await collection.findOne(filter);
    // If result is null or undefined, return null (document not found)
    return result || null;
  } catch (error) {
    // Handle "Document not found" as a normal case, return null
    // Check various error message patterns that indicate document not found
    const errorMessage = error?.message || '';
    if (errorMessage.includes('Document not found') || 
        errorMessage.includes('not found') ||
        errorMessage.includes('No document found')) {
      return null;
    }
    // For other database errors, re-throw them
    throw error;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

/**
 * Check for duplicate tax rate
 * Compares by: country, state, zipcode, city, and rate (if provided)
 */
async function findDuplicateTaxRate(taxRate, excludeId = null, region = DEFAULT_REGION) {
  let client;
  try {
    const { client: dbClient, collection } = await initDb(region);
    client = dbClient;
    
    // Build filter to check for duplicates
    const filter = {
      tax_country_id: taxRate.tax_country_id
    };
    
    // Include state if provided
    if (taxRate.tax_region_id) {
      filter.tax_region_id = taxRate.tax_region_id;
    } else {
      // If state is not provided, match records with no state
      filter.tax_region_id = { $in: [null, ''] };
    }
    
    // Include zipcode if provided
    if (taxRate.tax_postcode) {
      filter.tax_postcode = taxRate.tax_postcode;
    } else {
      // If zipcode is not provided, match records with no zipcode or '*'
      filter.tax_postcode = { $in: [null, '', '*'] };
    }
    
    // Include city if provided
    if (taxRate.city) {
      filter.city = taxRate.city;
    } else {
      // If city is not provided, match records with no city
      filter.city = { $in: [null, ''] };
    }
    
    // Include rate if provided
    if (taxRate.rate !== undefined && taxRate.rate !== null) {
      // Convert rate to string for comparison (handle both string and number)
      const rateValue = String(taxRate.rate);
      filter.rate = rateValue;
    } else {
      // If rate is not provided, match records with no rate
      filter.rate = { $in: [null, ''] };
    }
    
    // Exclude the current record if updating
    if (excludeId) {
      filter._id = { $ne: toObjectId(excludeId) };
    }
    
    try {
      const result = await collection.findOne(filter);
      return result || null;
    } catch (findError) {
      // Handle "Document not found" as a normal case - no duplicate found
      const errorMessage = findError?.message || '';
      if (errorMessage.includes('Document not found') || 
          errorMessage.includes('not found') ||
          errorMessage.includes('No document found')) {
        return null; // No duplicate found
      }
      // Re-throw other errors
      throw findError;
    }
  } catch (error) {
    // Handle "Document not found" at outer level too
    const errorMessage = error?.message || '';
    if (errorMessage.includes('Document not found') || 
        errorMessage.includes('not found') ||
        errorMessage.includes('No document found')) {
      return null; // No duplicate found
    }
    // Check if it's a database-related error by checking error name or message
    if (error && (error.name === 'DbError' || (error.message && error.message.includes('Database')))) {
      throw new Error(`Database error: ${error.message}`);
    }
    throw error;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

/**
 * Update a single tax rate
 */
async function updateTaxRate(filter, update, region = DEFAULT_REGION) {
  let client;
  try {
    const { client: dbClient, collection } = await initDb(region);
    client = dbClient;
    
    // Add updated_at timestamp
    const updateDoc = {
      ...update,
      $set: {
        ...(update.$set || {}),
        updated_at: new Date().toISOString()
      }
    };
    
    const result = await collection.updateOne(filter, updateDoc);
    return {
      success: result.modifiedCount > 0,
      matchedCount: result.matchedCount,
      modifiedCount: result.modifiedCount
    };
  } catch (error) {
    // Check if it's a database-related error by checking error name or message
    if (error && (error.name === 'DbError' || (error.message && error.message.includes('Database')))) {
      throw new Error(`Database error: ${error.message}`);
    }
    throw error;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

/**
 * Convert string _id to ObjectId
 */
function toObjectId(idString) {
  try {
    return new ObjectId(idString);
  } catch (error) {
    throw new Error(`Invalid ObjectId: ${idString}`);
  }
}

async function main(params) {
  // Handle OPTIONS preflight request for CORS
  const method = params["__ow_method"] || params.method || 'POST';
  if (method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, PUT, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-gw-ims-org-id',
        'Access-Control-Max-Age': '86400'
      },
      body: {}
    };
  }

  try {
    // Parse request body
    let body = null;
    if (params["__ow_body"]) {
      try {
        body = typeof params["__ow_body"] === 'string' 
          ? JSON.parse(params["__ow_body"]) 
          : params["__ow_body"];
      } catch (e) {
        console.error('Error parsing body:', e);
        return {
          statusCode: 400,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Error',
            message: 'Invalid JSON in request body: ' + e.message
          }
        };
      }
    }

    // Get operation from method
    const operation = method === 'POST' ? 'CREATE' : 
                     method === 'PUT' ? 'UPDATE' : 
                     (body?.operation || params.operation || 'CREATE').toUpperCase();
    
    // Get region from params or use default
    const region = body?.region || params.region || DEFAULT_REGION;

    // Get tax rate data
    let taxRate = body?.taxRate || params.taxRate;
    
    if (!taxRate) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: {
          status: 'Error',
          message: 'taxRate parameter is required'
        }
      };
    }

    // Handle CREATE operation
    if (operation === 'CREATE' || operation === 'POST') {
      try {
        // Remove _id if present (will be generated by database)
        const { _id, id, ...taxRateData } = taxRate;
        
        // Validate required fields
        if (!taxRateData.tax_country_id) {
          return {
            statusCode: 400,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Error',
              message: 'tax_country_id is required'
            }
          };
        }
        
        // Check for duplicate before creating
        let duplicate = null;
        try {
          duplicate = await findDuplicateTaxRate(taxRateData, null, region);
        } catch (dupError) {
          // If error is "Document not found", it means no duplicate exists - that's fine
          const errorMessage = dupError?.message || '';
          if (!errorMessage.includes('Document not found') && 
              !errorMessage.includes('not found')) {
            // Re-throw if it's a different error
            throw dupError;
          }
          // Otherwise, no duplicate found - continue with creation
        }
        
        if (duplicate) {
          return {
            statusCode: 409,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Error',
              message: 'Duplicate tax rate already exists',
              error: 'A tax rate with the same country, state, zipcode, city, and rate already exists',
              existingRecord: {
                _id: duplicate._id.toString(),
                tax_country_id: duplicate.tax_country_id,
                tax_region_id: duplicate.tax_region_id,
                tax_postcode: duplicate.tax_postcode,
                city: duplicate.city,
                rate: duplicate.rate
              }
            }
          };
        }
        
        // Insert into App Builder Database
        const result = await insertTaxRate(taxRateData, region);
      
      // Optionally sync to Magento if requested
      let magentoResponse = null;
      if (body?.syncToMagento !== false && params.syncToMagento !== false) {
        try {
          const commerceDomain = body?.commerceDomain || params.commerceDomain;
          const instanceId = body?.instanceId || params.instanceId || body?.tenantId || params.tenantId;
          const accessToken = body?.accessToken || params.accessToken || body?.bearerToken || params.bearerToken || body?.token || params.token;
          
          if (commerceDomain && accessToken) {
            // Filter out unsupported fields for Magento
            const unsupportedFields = ['region_code', 'city', 'zip_from', 'zip_to', 'magento_tax_rate_id', 'status', '_id', 'created_at', 'updated_at'];
            const magentoTaxRate = { ...taxRateData };
            unsupportedFields.forEach(field => {
              if (field in magentoTaxRate) {
                delete magentoTaxRate[field];
              }
            });
            
            const orgId = params["__ow_headers"]?.["x-gw-ims-org-id"] || body?.orgId || params.orgId || 'C116239B68225A790A495C96@AdobeOrg';
            const basicAuth = params.runtimeBasicAuth || body?.runtimeBasicAuth || 
                             'Basic YjQzYmUyMjAtZDU0ZC00MzE1LTk2ZjQtOWQwYmUxYjRhZDNjOmVrSzJVbWxNMFdnRmY2YmdqNXJVd3AyNnZhN081czdzVEpMUEpTOE8yeTB1ZjJYOGY2MjhrdzBWNDJqcUdKcTg=';
            
            const requestData = {
              operation: 'POST',
              commerceDomain: commerceDomain,
              instanceId: instanceId,
              accessToken: accessToken,
              taxRate: magentoTaxRate
            };
            
            const config = {
              method: 'post',
              maxBodyLength: Infinity,
              url: 'https://adobeioruntime.net/api/v1/namespaces/3676633-taxbycity-stage/actions/manage-tax?result=true&blocking=true',
              headers: { 
                'x-gw-ims-org-id': orgId, 
                'authorization': basicAuth,
                'Content-Type': 'application/json'
              },
              data: JSON.stringify(requestData)
            };
            
            magentoResponse = await axios.request(config);
            
            // Update the document with Magento tax rate ID if available
            if (magentoResponse?.data?.data?.id || magentoResponse?.data?.data?.tax_calculation_rate_id) {
              const magentoTaxRateId = magentoResponse.data.data.id || magentoResponse.data.data.tax_calculation_rate_id;
              await updateTaxRate(
                { _id: result.insertedId },
                { $set: { magento_tax_rate_id: magentoTaxRateId } },
                region
              );
            }
          }
        } catch (magentoError) {
          console.error('Error syncing to Magento (non-fatal):', magentoError.message);
          // Don't fail the request if Magento sync fails
        }
      }
      
      // Convert ObjectId to string
      const document = { ...result.document };
      if (document._id) {
        document._id = document._id.toString();
      }
      
        return {
          statusCode: 201,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Success',
            message: 'Tax rate created successfully in App Builder Database',
            data: document,
            magentoSync: magentoResponse ? {
              success: true,
              response: magentoResponse.data
            } : null
          }
        };
      } catch (createError) {
        // Handle errors during CREATE operation
        console.error('Error creating tax rate:', createError);
        return {
          statusCode: 500,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Error',
            message: 'Error creating tax rate: ' + createError.message,
            error: createError.message
          }
        };
      }
    }

    // Handle UPDATE operation
    if (operation === 'UPDATE' || operation === 'PUT') {
      const taxRateId = body?.id || body?._id || params.id || params._id;
      const filter = body?.filter || params.filter;
      
      if (!taxRateId && !filter) {
        return {
          statusCode: 400,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Error',
            message: 'id or filter parameter is required for UPDATE operation'
          }
        };
      }

      let updateFilter;
      if (taxRateId) {
        try {
          updateFilter = { _id: toObjectId(taxRateId) };
        } catch (e) {
          return {
            statusCode: 400,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Error',
              message: `Invalid tax rate ID format: ${e.message}`,
              providedId: taxRateId
            }
          };
        }
      } else {
        try {
          updateFilter = typeof filter === 'string' ? JSON.parse(filter) : filter;
        } catch (e) {
          return {
            statusCode: 400,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Error',
              message: 'Invalid filter format: ' + e.message
            }
          };
        }
      }

      // Get existing record to merge with update data
      let existingRecord;
      try {
        existingRecord = await findOneTaxRate(updateFilter, region);
      } catch (error) {
        // Handle "Document not found" as a normal case
        const errorMessage = error?.message || '';
        if (errorMessage.includes('Document not found') || 
            errorMessage.includes('not found') ||
            errorMessage.includes('No document found')) {
          existingRecord = null;
        } else {
          // For other errors, return them properly
          return {
            statusCode: 500,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Error',
              message: 'Error finding tax rate: ' + error.message
            }
          };
        }
      }
      
      // If document doesn't exist and we have an _id, create it (upsert behavior)
      if (!existingRecord) {
        if (taxRateId) {
          // Create new document with the provided _id
          const newTaxRate = {
            ...taxRate,
            _id: toObjectId(taxRateId)
          };
          
          // Check for duplicate before creating
          const duplicate = await findDuplicateTaxRate(newTaxRate, null, region);
          if (duplicate) {
            return {
              statusCode: 409,
              headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
              },
              body: {
                status: 'Error',
                message: 'Cannot create: duplicate tax rate already exists',
                error: 'A tax rate with the same country, state, zipcode, city, and rate already exists',
                existingRecord: {
                  _id: duplicate._id.toString(),
                  tax_country_id: duplicate.tax_country_id,
                  tax_region_id: duplicate.tax_region_id,
                  tax_postcode: duplicate.tax_postcode,
                  city: duplicate.city,
                  rate: duplicate.rate
                }
              }
            };
          }
          
          // Insert new document with specific _id
          const { _id: customId, ...taxRateData } = newTaxRate;
          // Add timestamps
          const document = {
            _id: customId,
            ...taxRateData,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
          
          let insertClient;
          try {
            const { client: dbClient, collection } = await initDb(region);
            insertClient = dbClient;
            await collection.insertOne(document);
          } catch (insertError) {
            // Handle duplicate key error (if _id already exists)
            if (insertError && insertError.message && insertError.message.includes('duplicate')) {
              // Document already exists, treat as update instead
              const update = { $set: taxRateData };
              await updateTaxRate({ _id: customId }, update, region);
            } else {
              throw insertError;
            }
          } finally {
            if (insertClient) {
              await insertClient.close();
            }
          }
          
          // Optionally sync to Magento if requested
          let magentoResponse = null;
          if (body?.syncToMagento !== false && params.syncToMagento !== false) {
            try {
              const commerceDomain = body?.commerceDomain || params.commerceDomain;
              const accessToken = body?.accessToken || params.accessToken;
              const instanceId = body?.instanceId || params.instanceId;
              
              if (commerceDomain && accessToken && instanceId) {
                const unsupportedFields = ['region_code', 'zip_from', 'zip_to', 'magento_tax_rate_id', 'status', '_id', 'created_at', 'updated_at'];
                const magentoTaxRate = { ...taxRateData };
                unsupportedFields.forEach(field => {
                  if (field in magentoTaxRate) {
                    delete magentoTaxRate[field];
                  }
                });
                
                const orgId = params["__ow_headers"]?.["x-gw-ims-org-id"] || body?.orgId || params.orgId || 'C116239B68225A790A495C96@AdobeOrg';
                const basicAuth = params.runtimeBasicAuth || body?.runtimeBasicAuth || 
                                 'Basic YjQzYmUyMjAtZDU0ZC00MzE1LTk2ZjQtOWQwYmUxYjRhZDNjOmVrSzJVbWxNMFdnRmY2YmdqNXJVd3AyNnZhN081czdzVEpMUEpTOE8yeTB1ZjJYOGY2MjhrdzBWNDJqcUdKcTg=';
                
                const requestData = {
                  operation: 'POST',
                  commerceDomain: commerceDomain,
                  instanceId: instanceId,
                  accessToken: accessToken,
                  taxRate: magentoTaxRate
                };
                
                const config = {
                  method: 'post',
                  maxBodyLength: Infinity,
                  url: 'https://adobeioruntime.net/api/v1/namespaces/3676633-taxbycity-stage/actions/manage-tax?result=true&blocking=true',
                  headers: { 
                    'x-gw-ims-org-id': orgId, 
                    'authorization': basicAuth,
                    'Content-Type': 'application/json'
                  },
                  data: JSON.stringify(requestData)
                };
                
                magentoResponse = await axios.request(config);
                
                // Update the document with magento_tax_rate_id if sync was successful
                if (magentoResponse?.data?.body?.data?.id) {
                  const updateDoc = {
                    $set: {
                      magento_tax_rate_id: magentoResponse.data.body.data.id
                    }
                  };
                  await updateTaxRate({ _id: toObjectId(taxRateId) }, updateDoc, region);
                }
              }
            } catch (magentoError) {
              console.error('Error syncing to Magento (non-fatal):', magentoError.message);
              // Don't fail the request if Magento sync fails
            }
          }
          
          // Fetch the created/updated document
          const createdDoc = await findOneTaxRate({ _id: customId }, region);
          if (createdDoc && createdDoc._id) {
            createdDoc._id = createdDoc._id.toString();
          }
          
          return {
            statusCode: 201,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Success',
              message: 'Tax rate created successfully (upsert)',
              data: createdDoc || document,
              magentoSync: magentoResponse ? {
                success: true,
                response: magentoResponse.data
              } : null
            }
          };
        } else {
          // No _id provided, cannot create
          return {
            statusCode: 404,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Content-Type': 'application/json'
            },
            body: {
              status: 'Not Found',
              message: 'Tax rate not found. Provide _id to create new record.',
              filter: updateFilter
            }
          };
        }
      }
      
      // Document exists, proceed with update
      // Merge existing data with update data
      const mergedData = {
        ...existingRecord,
        ...taxRate,
        _id: existingRecord._id // Preserve _id
      };
      
      // Remove _id from update data
      const { _id, ...updateData } = mergedData;
      
      // Check for duplicate before updating (exclude current record)
      const duplicate = await findDuplicateTaxRate(updateData, existingRecord._id.toString(), region);
      if (duplicate) {
        return {
          statusCode: 409,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Error',
            message: 'Update would create a duplicate tax rate',
            error: 'Another tax rate with the same country, state, zipcode, city, and rate already exists',
            existingRecord: {
              _id: duplicate._id.toString(),
              tax_country_id: duplicate.tax_country_id,
              tax_region_id: duplicate.tax_region_id,
              tax_postcode: duplicate.tax_postcode,
              city: duplicate.city,
              rate: duplicate.rate
            }
          }
        };
      }
      
      const update = { $set: updateData };
      const result = await updateTaxRate(updateFilter, update, region);
      
      if (result.success) {
        // Fetch updated document
        const updatedDoc = await findOneTaxRate(updateFilter, region);
        if (updatedDoc && updatedDoc._id) {
          updatedDoc._id = updatedDoc._id.toString();
        }
        
        // Optionally sync to Magento if requested
        let magentoResponse = null;
        if (body?.syncToMagento !== false && params.syncToMagento !== false) {
          try {
            const commerceDomain = body?.commerceDomain || params.commerceDomain;
            const instanceId = body?.instanceId || params.instanceId || body?.tenantId || params.tenantId;
            const accessToken = body?.accessToken || params.accessToken || body?.bearerToken || params.bearerToken || body?.token || params.token;
            
            if (commerceDomain && accessToken && updatedDoc?.magento_tax_rate_id) {
              // Filter out unsupported fields for Magento
              const unsupportedFields = ['region_code', 'city', 'zip_from', 'zip_to', 'magento_tax_rate_id', 'status', '_id', 'created_at', 'updated_at'];
              const magentoTaxRate = { ...updateData };
              unsupportedFields.forEach(field => {
                if (field in magentoTaxRate) {
                  delete magentoTaxRate[field];
                }
              });
              
              const orgId = params["__ow_headers"]?.["x-gw-ims-org-id"] || body?.orgId || params.orgId || 'C116239B68225A790A495C96@AdobeOrg';
              const basicAuth = params.runtimeBasicAuth || body?.runtimeBasicAuth || 
                               'Basic YjQzYmUyMjAtZDU0ZC00MzE1LTk2ZjQtOWQwYmUxYjRhZDNjOmVrSzJVbWxNMFdnRmY2YmdqNXJVd3AyNnZhN081czdzVEpMUEpTOE8yeTB1ZjJYOGY2MjhrdzBWNDJqcUdKcTg=';
              
              const requestData = {
                operation: 'PUT',
                commerceDomain: commerceDomain,
                instanceId: instanceId,
                accessToken: accessToken,
                taxRate: {
                  ...magentoTaxRate,
                  id: updatedDoc.magento_tax_rate_id
                }
              };
              
              const config = {
                method: 'post',
                maxBodyLength: Infinity,
                url: 'https://adobeioruntime.net/api/v1/namespaces/3676633-taxbycity-stage/actions/manage-tax?result=true&blocking=true',
                headers: { 
                  'x-gw-ims-org-id': orgId, 
                  'authorization': basicAuth,
                  'Content-Type': 'application/json'
                },
                data: JSON.stringify(requestData)
              };
              
              magentoResponse = await axios.request(config);
            }
          } catch (magentoError) {
            console.error('Error syncing to Magento (non-fatal):', magentoError.message);
            // Don't fail the request if Magento sync fails
          }
        }
        
        return {
          statusCode: 200,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Success',
            message: 'Tax rate updated successfully in App Builder Database',
            data: updatedDoc,
            result: result,
            magentoSync: magentoResponse ? {
              success: true,
              response: magentoResponse.data
            } : null
          }
        };
      } else {
        return {
          statusCode: 404,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: {
            status: 'Not Found',
            message: 'Tax rate not found',
            result: result
          }
        };
      }
    }

    // Unknown operation
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: {
        status: 'Error',
        message: `Unsupported operation: ${operation}. Supported operations: CREATE, UPDATE`
      }
    };
  } catch (error) {
    console.error('Error processing request:', error);
    
    // Handle "Document not found" errors - these should be 404, not 500
    const errorMessage = error?.message || '';
    if (errorMessage.includes('Document not found') || 
        errorMessage.includes('not found') ||
        errorMessage.includes('No document found')) {
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: {
          status: 'Not Found',
          message: 'Tax rate not found',
          error: errorMessage
        }
      };
    }
    
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: {
        status: 'Error',
        message: 'Error processing tax rate request',
        error: error.message,
        errorDetails: error.response ? {
          status: error.response.status,
          statusText: error.response.statusText,
          data: error.response.data
        } : null
      }
    };
  }
}

exports.main = main;
