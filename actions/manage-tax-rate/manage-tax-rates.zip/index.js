/*
 * Manage Tax Rate Action (Web Action Safe)
 * Flow:
 * 1. Create / Update tax rate in Magento Commerce
 * 2. Persist tax rate in App Builder Database (only if Magento succeeds)
 */

require('dotenv').config();

const axios = require('axios');
const libDb = require('@adobe/aio-lib-db');
const { ObjectId } = require('bson');

const COLLECTION_NAME = 'tax_rates';
const DEFAULT_REGION = 'amer';

/* --------------------------------------------------------------------------
 * MAGENTO CONFIG (ENV ONLY)
 * -------------------------------------------------------------------------- */
function getMagentoConfig() {
  const {
    MAGENTO_COMMERCE_DOMAIN,
    MAGENTO_INSTANCE_ID,
    ADOBE_CLIENT_ID,
    ADOBE_CLIENT_SECRET,
    ADOBE_TOKEN_URL,
    ADOBE_SCOPE,
    MAGENTO_ACCESS_TOKEN
  } = process.env;

  if (!MAGENTO_COMMERCE_DOMAIN || !ADOBE_CLIENT_ID || !ADOBE_CLIENT_SECRET) {
    throw new Error('Missing Magento / Adobe environment variables');
  }

  return {
    commerceDomain: MAGENTO_COMMERCE_DOMAIN,
    instanceId: MAGENTO_INSTANCE_ID,
    clientId: ADOBE_CLIENT_ID,
    clientSecret: ADOBE_CLIENT_SECRET,
    tokenUrl:
      ADOBE_TOKEN_URL || 'https://ims-na1.adobelogin.com/ims/token/v3',
    scope:
      ADOBE_SCOPE ||
      'AdobeID,openid,read_organizations,additional_info.projectedProductContext,additional_info.roles,adobeio_api',
    accessToken: MAGENTO_ACCESS_TOKEN
  };
}

/* --------------------------------------------------------------------------
 * AUTH
 * -------------------------------------------------------------------------- */
async function generateAccessToken(config) {
  const response = await axios.post(config.tokenUrl, null, {
    params: {
      client_id: config.clientId,
      client_secret: config.clientSecret,
      grant_type: 'client_credentials',
      scope: config.scope
    },
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });

  return response.data.access_token;
}

async function getAccessToken(config) {
  return config.accessToken || generateAccessToken(config);
}

/* --------------------------------------------------------------------------
 * MAGENTO
 * -------------------------------------------------------------------------- */
function formatMagentoTaxRatePayload(data) {
  return {
    tax_country_id: data.tax_country_id || 'US',
    rate: Number(data.rate) || 0,
    code:
      data.code ||
      `${data.tax_country_id || 'US'}-${data.tax_region_id || 'ALL'}-${data.rate || 0}`,
    region_name: data.tax_region_id || null,
    tax_postcode: data.tax_postcode || '*',
    zip_is_range: data.zip_is_range ? 1 : 0,
    titles: [
      {
        store_id: '0',
        value: `${data.tax_region_id || 'All'} - ${data.rate || 0}%`
      }
    ]
  };
}

function buildMagentoUrl(domain, instanceId, identifier = null) {
  const base = `https://${domain}/${instanceId}/V1/taxRates`;
  return identifier ? `${base}/${identifier}` : base;
}

async function syncToMagento(data, operation, taxIdentifier = null) {
  const config = getMagentoConfig();
  const token = await getAccessToken(config);

  const url = buildMagentoUrl(
    config.commerceDomain,
    config.instanceId,
    operation === 'UPDATE' ? taxIdentifier : null
  );

  try {
    const response = await axios({
      method: operation === 'UPDATE' ? 'put' : 'post',
      url,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      data: {
        taxRate: formatMagentoTaxRatePayload(data)
      }
    });

    return {
      taxIdentifier:
        response.data?.tax_identifier ||
        response.data?.id ||
        taxIdentifier,
      response: response.data
    };
  } catch (error) {
    console.error('Magento API Error:', error.response?.data || error.message);
    throw new Error(
      `Request failed with status code ${error.response?.status || 'unknown'}. ` +
      `Details: ${JSON.stringify(error.response?.data || error.message)}`
    );
  }
}

/* --------------------------------------------------------------------------
 * DATABASE
 * -------------------------------------------------------------------------- */
async function initDb(region) {
  const db = await libDb.init({ region });
  const client = await db.connect();
  return { client, collection: client.collection(COLLECTION_NAME) };
}

async function insertTaxRate(data, region) {
  const { client, collection } = await initDb(region);
  const result = await collection.insertOne({
    ...data,
    created_at: new Date(),
    updated_at: new Date()
  });
  await client.close();
  return result.insertedId;
}

async function updateTaxRate(filter, data, region) {
  const { client, collection } = await initDb(region);
  const result = await collection.updateOne(filter, {
    $set: { ...data, updated_at: new Date() }
  });
  await client.close();
  return result.modifiedCount > 0;
}

async function findTaxRate(filter, region) {
  const { client, collection } = await initDb(region);
  const doc = await collection.findOne(filter);
  await client.close();
  return doc;
}

/* --------------------------------------------------------------------------
 * MAIN (WEB ACTION SAFE)
 * -------------------------------------------------------------------------- */
async function main(params) {
  const method = params.__ow_method || 'POST';

  let body = {};

  /* ---------- Case 1: Normal action invocation ---------- */
  if (params.__ow_body) {
    body =
      typeof params.__ow_body === 'string'
        ? JSON.parse(params.__ow_body)
        : params.__ow_body;
  }

  /* ---------- Case 2: Web Action (CRITICAL FIX) ---------- */
  if (!body.taxRate && params.taxRate) {
    body = params;
  }

  const region = body.region || DEFAULT_REGION;
  const taxRate = body.taxRate;

  if (!taxRate) {
    return {
      statusCode: 400,
      headers: {
        'Content-Type': 'application/json'
      },
      body: {
        status: 'Error',
        message: 'taxRate is required',
        receivedKeys: Object.keys(params)
      }
    };
  }

  /* ---------------- CREATE ---------------- */
  if (method === 'POST') {
    const magento = await syncToMagento(taxRate, 'CREATE');

    const id = await insertTaxRate(
      { ...taxRate, tax_identifier: magento.taxIdentifier },
      region
    );

    return {
      statusCode: 201,
      headers: {
        'Content-Type': 'application/json'
      },
      body: {
        status: 'Success',
        id,
        magento
      }
    };
  }

  /* ---------------- UPDATE ---------------- */
  if (method === 'PUT') {
    if (!body._id) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json'
        },
        body: { 
          status: 'Error',
          message: '_id is required for update' 
        }
      };
    }

    const existing = await findTaxRate(
      { _id: new ObjectId(body._id) },
      region
    );

    if (!existing) {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json'
        },
        body: { 
          status: 'Error',
          message: 'Tax rate not found' 
        }
      };
    }

    const magento = await syncToMagento(
      { ...existing, ...taxRate },
      'UPDATE',
      existing.tax_identifier
    );

    await updateTaxRate(
      { _id: existing._id },
      { ...taxRate, tax_identifier: magento.taxIdentifier },
      region
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: {
        status: 'Success',
        magento
      }
    };
  }

  return {
    statusCode: 405,
    headers: {
      'Content-Type': 'application/json'
    },
    body: { message: 'Method not allowed' }
  };
}

// Wrap main to ensure proper response format for web actions
async function wrappedMain(params) {
  try {
    const result = await main(params);
    
    // Ensure result is always a valid web action response
    if (!result || typeof result !== 'object') {
      return {
        statusCode: 500,
        headers: {
          'Content-Type': 'application/json'
        },
        body: {
          status: 'Error',
          message: 'Invalid response format from action'
        }
      };
    }
    
    // Ensure all required fields exist
    const finalResult = {
      statusCode: typeof result.statusCode === 'number' ? result.statusCode : 200,
      headers: {
        'Content-Type': 'application/json',
        ...(result.headers || {})
      },
      body: result.body || {}
    };
    
    // Ensure body is always an object
    if (!finalResult.body || typeof finalResult.body !== 'object' || Array.isArray(finalResult.body)) {
      finalResult.body = Array.isArray(finalResult.body) 
        ? { status: 'Success', data: finalResult.body }
        : (finalResult.body || { status: 'Success' });
    }
    
    return finalResult;
  } catch (error) {
    console.error('Error in wrappedMain:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json'
      },
      body: {
        status: 'Error',
        message: error.message || 'Internal server error',
        error: process.env.LOG_LEVEL === 'debug' ? error.stack : undefined
      }
    };
  }
}

exports.main = wrappedMain;
