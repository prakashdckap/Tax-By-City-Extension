/**
 * DB connection debug action.
 * Call this to get the exact error when App Builder DB connection fails.
 * Returns: ok, errorDetails (message, code, status), hasAuthInParams, paramKeys, region.
 * No secrets are logged or returned.
 */
const libDb = require('@adobe/aio-lib-db');

const DEFAULT_REGION = 'amer';

async function main(params) {
  const region = params.region || DEFAULT_REGION;
  const paramKeys = Object.keys(params || {}).filter(k => !k.startsWith('__ow_') || k === '__ow_headers');
  const hasAuthInParams = !!(params && (
    (params.__ow_headers && (params.__ow_headers.authorization || params.__ow_headers.Authorization)) ||
    params.auth || params.token || params.access_token
  ));
  const hasOwHeaders = !!(params && params.__ow_headers);

  let result = {
    ok: false,
    region,
    hasAuthInParams,
    hasOwHeaders,
    paramKeysSample: paramKeys.slice(0, 20),
    errorDetails: null,
    step: null
  };

  try {
    result.step = 'init';
    const db = await libDb.init({ region });
    result.step = 'connect';
    const client = await db.connect();
    result.step = 'collection';
    const collection = await client.collection('tax_rates');
    const count = await collection.find({}).limit(1).toArray();
    await client.close();
    result.ok = true;
    result.step = 'done';
    result.collectionSample = Array.isArray(count) ? count.length : 0;
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: result
    };
  } catch (error) {
    result.errorDetails = {
      message: error && error.message,
      name: error && error.name,
      code: error && error.code,
      status: error && error.status,
      statusCode: error && error.statusCode,
      stack: error && error.stack ? error.stack.split('\n').slice(0, 5) : undefined
    };
    result.step = result.step || 'init';
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: result
    };
  }
}

exports.main = main;
